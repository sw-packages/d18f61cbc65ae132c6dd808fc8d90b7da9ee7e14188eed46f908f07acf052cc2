#include "utf.h"

// `utf16_from_utf8` is Windows-only.
